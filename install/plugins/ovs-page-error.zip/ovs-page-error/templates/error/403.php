<?php

/**
 * The template for displaying 404 pages (not found).
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package Astra
 * @since 1.0.0
 */
if (isset($_COOKIE['ovs-key'])) {
    unset($_COOKIE['ovs-key']);
    setcookie('ovs-key', null, -1, '/');
}
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

$style = URL_PLUGIN_ERROR . '/assets/css/403.css';
?>

<head>
	<meta>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>
		<?= esc_html__('Interdit !!!', 'ovs') ?>
	</title>
	<link rel="apple-touch-icon" sizes="180x180"
		href="<?= URL_PLUGIN_ERROR . '/assets/img/favicon_403/apple-touch-icon.png' ?>">
	<link rel="icon" type="image/png" sizes="32x32"
		href="<?= URL_PLUGIN_ERROR . '/assets/img/favicon_403/favicon-32x32.png' ?>">
	<link rel="icon" type="image/png" sizes="16x16"
		href="<?= URL_PLUGIN_ERROR . '/assets/img/favicon_403/favicon-16x16.png' ?>">
	<link rel="manifest"
		href="<?= URL_PLUGIN_ERROR . '/assets/img/favicon_403/site.webmanifest'?>">
	<meta name="robots" content="noindex">
	<link rel="stylesheet" href="<?= $style ?>">
</head>

<body>
	<lottie-player src="https://assets4.lottiefiles.com/packages/lf20_llhmewas.json" background="transparent" speed="1"
		autoplay></lottie-player>
	<h1><?= esc_html__('ACCÈS FORMELLEMENT INTERDIT !', 'ovs') ?>
	</h1>
	<p><?= esc_html__('Désolé, vous n\'êtes pas autorisé à accéder à cette page.', 'ovs') ?>
	</p>
	<a href="/"
		title="<?= esc_html__('Retour à l\'accueil', 'ovs') ?>"
		class="btn"><?= esc_html__('Retour à l\'accueil', 'ovs') ?></a>
	<script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
</body>