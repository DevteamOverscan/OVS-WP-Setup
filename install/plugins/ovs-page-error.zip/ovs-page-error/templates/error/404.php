<?php

/**
 * The template for displaying 404 pages (not found).
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package OVS Page Error
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}
$style = URL_PLUGIN_ERROR . '/assets/css/404.css';
$lottie = URL_PLUGIN_ERROR . '/assets/lottie/lonely-404.json';
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>

	<head>
		<meta
			charset="<?php bloginfo('charset'); ?>">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link rel="apple-touch-icon" sizes="180x180"
			href="<?= URL_PLUGIN_ERROR . '/assets/img/favicon_404/apple-touch-icon.png' ?>">
		<link rel="icon" type="image/png" sizes="32x32"
			href="<?= URL_PLUGIN_ERROR . '/assets/img/favicon_404/favicon-32x32.png' ?>">
		<link rel="icon" type="image/png" sizes="16x16"
			href="<?= URL_PLUGIN_ERROR . '/ovs/assets/img/favicon_404/favicon-16x16.png' ?>">
		<link rel="manifest"
			href="<?= URL_PLUGIN_ERROR . '/assets/img/favicon_404/site.webmanifest'?>">
		<link
			href="https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500;1,600;1,700&family=Ubuntu:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap"
			rel="stylesheet">
		<link rel="profile" href="https://gmpg.org/xfn/11">
		<link rel="stylesheet" href="<?= $style ?>">
	</head>

	<body class="error-404">
		<section>
			<lottie-player src="<?= $lottie ?>"
				background="transparent" speed="1" loop autoplay></lottie-player>
			<div>
				<h1><?= esc_html__('Page Introuvable', 'ovs') ?>
				</h1>
				<p><?= esc_html__('Désolé, il me semble que vous soyez perdu !', 'ovs') ?>
				</p>
				<a href="/"
					title="<?= esc_html__('Retour à l\'accueil', 'ovs') ?>"
					class="btn"><?= esc_html__('Retour à l\'accueil', 'ovs') ?></a>
			</div>
		</section>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
		<script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
	</body>

</html>