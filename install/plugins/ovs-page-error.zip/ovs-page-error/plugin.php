<?php

/**
 * Class CustomErrorPage
 * @package OVS Page Error
 * @author Clément Vacheron
 * @link https://www.overscan.com
 * Main CustomErrorPage class
 * @since 1
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class CustomErrorPage
{
    /**
     * Instance
     *
     * @since 1
     * @access private
     * @static
     *
     * @var CustomErrorPage The single instance of the class.
     */
    private static $_instance = null;

    /**
     * Instance
     *
     * Ensures only one instance of the class is loaded or can be loaded.
     *
     * @since 1
     * @access public
     *
     * @return CustomErrorPage An instance of the class.
     */
    public static function instance()
    {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }


    /**
     *  Plugin class constructor
     *
     * Register plugin action hooks and filters
     *
     * @since 1.2.0
     * @access public
     */
    public function __construct()
    {
        if(str_contains(dirname(__FILE__), 'mu-plugins')) {
            define('URL_PLUGIN_ERROR', WPMU_PLUGIN_URL .'/ovs-page-error');
        } else {
            var_dump('plugins');
            define('URL_PLUGIN_ERROR', WP_PLUGIN_URL .'/ovs-page-error');
        }

        if(file_exists(URL_PLUGIN_ERROR)) {

            register_activation_hook(__FILE__, array($this, 'plugin_activation'));
        }
        register_deactivation_hook(__FILE__, array($this, 'plugin_deactivation'));
        add_action('template_redirect', array($this, 'handler_error'), 1);
    }

    public function plugin_activation()
    {
        // Add code
    }

    public function plugin_deactivation()
    {
        // Add code
    }

    public function custom_template_include($template)
    {
        // Chemin vers votre template personnalisé
        $custom_template = dirname(__FILE__) . '/templates/error/' . http_response_code() . '.php';

        if (file_exists($custom_template)) {
            return $custom_template;
        }


        return $template;
    }

    public function handler_error()
    {
        if(is_404() || http_response_code() == '404') {
            add_filter('template_include', array($this,'custom_template_include'));
        }
        if(http_response_code() == '403') {
            add_filter('template_include', array($this,'custom_template_include'));
        }
    }


}

// Instantiate Plugin Class
CustomErrorPage::instance();
