<?php

//The way is closed, it was made by those who died; and the dead guard it… the way is closed
