let allImages = document.querySelectorAll('img');
allImages.forEach((value) => {
	value.oncontextmenu = (e) => {
		e.preventDefault();
	};
});
jQuery(document).ready(function ($) {
	var acivTextColor = $('button.filter.active').data('color');
	$('button.filter.active').css('color', acivTextColor);
});
jQuery('button.filter').on('click', function () {
	jQuery('button.filter.active').removeClass('active').removeAttr('style');
	var acivTextColor = jQuery(this).data('color');
	jQuery(this).addClass('active').css('color', acivTextColor);

	var val = jQuery(this).data('target');
	if (val === 'all') {
		resetFilter();
	} else {
		filterPosts(val);
	}
});
jQuery('button.subfilter').on('click', function () {
	var subfilter = jQuery(this).data('target');
	var filter = jQuery(this).parent().data('filter');
	jQuery('button.subfilter.active').removeClass('active').removeAttr('style');
	var acivTextColor = jQuery(this).data('color');
	jQuery(this).addClass('active').css('color', acivTextColor);
	// jQuery(this).addClass("active");
	jQuery('.post-item').each(function (index, el) {
		jQuery(el).addClass('d-none');
		var dataCategory = jQuery(el).data('category');
		var dataTypes = jQuery(el).data('type');
		if (
			typeof dataCategory !== 'undefined' &&
			typeof dataTypes !== 'undefined'
		) {
			var arrayCategory = dataCategory.split(' ');
			var arrayTypes = dataTypes.split(' ');
			if (arrayCategory.includes(filter) && arrayTypes.includes(subfilter)) {
				jQuery(el).removeClass('d-none');
			}
		}
	});
});
function resetFilter() {
	jQuery('.post-item').each(function (index, el) {
		if (jQuery(el).hasClass('d-none')) {
			jQuery(el).removeClass('d-none');
		}
	});
	jQuery('button.subfilter.active').removeClass('active');
}
function filterPosts(target) {
	resetFilter();
	jQuery('.post-item').each(function (index, el) {
		var dataCategory = jQuery(el).data('category');
		jQuery(el).addClass('d-none');
		if (typeof dataCategory !== 'undefined') {
			var arrayCategory = dataCategory.split(' ');
			if (arrayCategory.includes(target)) {
				jQuery(el).removeClass('d-none');
			}
		}
	});
}

jQuery(window).bind('scroll', function () {
	if (jQuery(window).scrollTop() > 150) {
		jQuery('header.header-nav').addClass('fixed');
	} else {
		jQuery('header.header-nav').removeClass('fixed');
	}
});
