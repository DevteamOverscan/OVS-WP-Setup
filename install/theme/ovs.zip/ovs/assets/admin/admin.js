// document.addEventListener("DOMContentLoaded", function () {
//   // on upload button click
//   document.body.addEventListener("click", function (e) {
//     var button = e.target.closest(".cv-upl-img");

//     if (button) {
//       e.preventDefault();

//       var customUploader = wp.media({
//         title: "Choisir l'image",
//         library: {
//           type: "image",
//         },
//         button: {
//           text: "Sélectionner l'image",
//         },
//         multiple: false,
//       });

//       customUploader.on("select", function () {
//         var attachment = customUploader
//           .state()
//           .get("selection")
//           .first()
//           .toJSON();
//         button.innerHTML = '<img src="' + attachment.url + '" class="cv-custom-img">';
//         document.querySelector(".cv_save_img").value = attachment.id;
//       });

//       customUploader.open();
//     }
//   });

//   // on remove button click
//   document.body.addEventListener("click", function (e) {
//     var button = e.target.closest(".cv-rmv-img");

//     if (button) {
//       e.preventDefault();
//       var hiddenField = button.nextElementSibling;
//       hiddenField.value = ""; // emptying the hidden field
//       button.style.display = "none";
//       button.previousElementSibling.innerHTML = "Upload image";
//     }
//   });
// });

// var myOptions = {
//   defaultColor: "111111",
//   color: true,
//   change: function (event, ui) {
//     console.log(ui.color.toString());
//     document.getElementById("_category_color").value = ui.color.toString();
//   },
//   clear: function () {},
//   hide: true,
//   palettes: true,
// };

// var colorPicker = document.querySelector(".color-picker");
// wpColorPicker(colorPicker, myOptions);

// document.getElementById("cv_second_type").addEventListener("change", function () {
//   var target = this.value;
//   var scdTypeCatShow = document.querySelector(".scdType-cat.show");
//   var scdTypeTarget = document.querySelector(".scdType-" + target);

//   scdTypeCatShow.classList.remove("show");

//   scdTypeTarget.classList.add("show");
// });

// // jQuery(function ($) {
// // 	// on upload button click
// // 	$("body").on("click", ".cv-upl-img", function (e) {
// // 		e.preventDefault();

// // 		var button = $(this),
// // 			custom_uploader = wp
// // 				.media({
// // 					title: "Choisir l'image",
// // 					library: {
// // 						// uploadedTo : wp.media.view.settings.post.id, // attach to the current post?
// // 						type: "image",
// // 					},
// // 					button: {
// // 						text: "Sélectionner l'image", // button label text
// // 					},
// // 					multiple: false,
// // 				})
// // 				.on("select", function () {
// // 					// it also has "open" and "close" events
// // 					var attachment = custom_uploader
// // 						.state()
// // 						.get("selection")
// // 						.first()
// // 						.toJSON();
// // 					button.html(
// // 						'<img src="' + attachment.url + '" class="cv-custom-img">'
// // 					);
// // 					$(".cv_save_img").val(attachment.id);
// // 				})
// // 				.open();
// // 	});

// // 	// on remove button click
// // 	$("body").on("click", ".cv-rmv-img", function (e) {
// // 		e.preventDefault();

// // 		var button = $(this);
// // 		button.next().val(""); // emptying the hidden field
// // 		button.hide().prev().html("Upload image");
// // 	});
// // });

// // var myOptions = {
// // 	// you can declare a default color here,
// // 	// or in the data-default-color attribute on the input
// // 	defaultColor: "111111",
// // 	color: true,
// // 	// a callback to fire whenever the color changes to a valid color
// // 	change: function (event, ui) {
// // 		console.log(ui.color.toString());
// // 		jQuery("#_category_color").val(ui.color.toString());
// // 	},
// // 	// a callback to fire when the input is emptied or an invalid color

// // 	clear: function () {},
// // 	// hide the color picker controls on load
// // 	hide: true,
// // 	// show a group of common colors beneath the square
// // 	// or, supply an array of colors to customize further
// // 	palettes: true,
// // };

// // jQuery(".color-picker").wpColorPicker(myOptions);

// // jQuery("#cv_second_type").change(function () {
// // 	var target = jQuery(this).val();
// // 	jQuery(".scdType-cat.show input").each(function (i, el) {
// // 		jQuery(el).removeAttr("checked");
// // 	});
// // 	jQuery(".scdType-cat.show").removeClass("show");
// // 	jQuery(".scdType-" + target).addClass("show");
// // });
