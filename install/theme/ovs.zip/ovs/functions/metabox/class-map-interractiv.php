<?php

/**
 * Custom MetaBox SecondType
 *
 * @package Ousortir
 * @author Clément Vacheron
 * @link https://www.overscan.com
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

if (!class_exists('CV_SecondType_MetaBox')) {
    class CV_SecondType_MetaBox
    {
        //Variable

        /**
         * nom du post type cibler
         */
        protected $postType;

        public function setPostType($value)
        {
            $this->postType = $value;
            return $this->postType;
        }
        public function getPostType()
        {
            return $this->postType;
        }
        /**
         * Constructor.
         */
        public function __construct()
        {
            if (is_admin()) {
                add_action('load-post.php', array($this, 'init_metabox'));
                add_action('load-post-new.php', array($this, 'init_metabox'));
            }
        }

        /**
         * Meta box initialization.
         */
        public function init_metabox()
        {
            add_action('add_meta_boxes', array($this, 'add_metabox'));
            add_action('save_post', array($this, 'save_metabox'), 10, 2);
        }

        /**
         * Adds the meta box.
         */
        public function add_metabox()
        {
            add_meta_box(
                'settings-meta-box',
                __('A propos du projet', 'ovs'),
                array($this, 'render_metabox'),
                'projects',
                'normal',
                'high'
            );
        }
        /**
         * Renders the meta box.
         */
        public function render_metabox($post)
        {
            $projectOnHome = get_post_meta($post->ID, 'project_on_home', true);
            $projectAdress = get_post_meta($post->ID, 'project_address', true);
            $latAdress = get_post_meta($post->ID, 'lat_address', true);
            $lonAdress = get_post_meta($post->ID, 'lon_address', true);
            $projectDescription = get_post_meta($post->ID, 'project_description', true);

            $selected = '';
            if ($projectOnHome == 'true') {
                $selected = 'selected';
            }
            // Add nonce for security and authentication.
            wp_nonce_field('event_metabox', 'event_metabox_nonce');

            $field = '<div>';
            $field .= '<table class="project-table">';
            $field .= '<tr>';
            $field .= '<td>';
            $field .= '<label for="project_on_home">Afficher ce projet sur la homepage : </label>';
            $field .= '</td>';
            $field .= '<td>';
            $field .= '<select name="project_on_home" id="project_on_home">';
            $field .= '<option value="false"> NON </option>';
            $field .= '<option value="true" '. $selected .'> OUI </option>';
            $field .= '</td>';
            $field .= '</tr>';
            $field .= '<tr>';
            $field .= '<td>';
            $field .= '<label for="project_address">L\'adresse du projet : </label>';
            $field .= '</td>';
            $field .= '<td>';
            $field .= '<input type="text" name="project_address" id="project_address" value="'. $projectAdress .'" placeholder="Ex: 1 avenue Michel Ange, Clermont-ferrand"> <button class="address_button">Rechercher la longitude/latitude</button>';
            $field .= '</td>';
            $field .= '</tr>';
            $field .= '<tr>';
            $field .= '<td>';
            $field .= '<label for="lat_address">Latitude du projet : </label>';
            $field .= '</td>';
            $field .= '<td>';
            $field .= '<input type="text" name="lat_address" id="lat_address" value="'. $latAdress .'">';
            $field .= '</td>';
            $field .= '</tr>';
            $field .= '<tr>';
            $field .= '<td>';
            $field .= '<label for="lon_address">Longitude du projet : </label>';
            $field .= '</td>';
            $field .= '<td>';
            $field .= '<input type="text" name="lon_address" id="lon_address" value="'. $lonAdress .'">';
            $field .= '</td>';
            $field .= '</tr>';
            $field .= '<tr>';
            $field .= '<td>';
            $field .= '<label for="project_description">Description : </label>';
            $field .= '</td>';
            $field .= '<td>';
            $field .= '<textarea name="project_description" id="project_description" placeholder="Votre description...">'. $projectDescription .'</textarea>';
            $field .= '</td>';
            $field .= '</tr>';
            $field .= '</table>';
            $field .= '</div>';

            echo $field;
        }

        /**
         * Handles saving the meta box.
         *
         * @param int     $post_id Post ID.
         * @param WP_Post $post    Post object.
         * @return null
         */
        public function save_metabox($post_id, $post)
        {
            // Add nonce for security and authentication.
            // $nonce_name   = isset($_POST['projects_metabox_nonce']) ? $_POST['projects_metabox_nonce'] : '';
            // $nonce_action = 'projects_metabox';

            // Check if nonce is valid.
            // if (!wp_verify_nonce($nonce_name, $nonce_action)) {
            //     return;
            // }

            // Check if user has permissions to save data.
            if (!current_user_can('edit_post', $post_id)) {
                return $post_id;
            }

            // Check if not an autosave.
            if (wp_is_post_autosave($post_id)) {
                return $post_id;
            }

            // Check if not a revision.
            if (wp_is_post_revision($post_id)) {
                return;
            }
            if (isset($_POST['project_on_home']) && array_key_exists('project_on_home', $_POST)) {
                update_post_meta(
                    $post_id,
                    'project_on_home',
                    $_POST['project_on_home']
                );
            }
            if (isset($_POST['project_address']) && array_key_exists('project_address', $_POST)) {
                update_post_meta(
                    $post_id,
                    'project_address',
                    $_POST['project_address']
                );
            }
            if (isset($_POST['lat_address']) && array_key_exists('lat_address', $_POST)) {
                update_post_meta(
                    $post_id,
                    'lat_address',
                    $_POST['lat_address']
                );
            }
            if (isset($_POST['lon_address']) && array_key_exists('lon_address', $_POST)) {
                update_post_meta(
                    $post_id,
                    'lon_address',
                    $_POST['lon_address']
                );
            }
            if (isset($_POST['project_description']) && array_key_exists('project_description', $_POST)) {
                update_post_meta(
                    $post_id,
                    'project_description',
                    $_POST['project_description']
                );
            }
        }
    }
}
