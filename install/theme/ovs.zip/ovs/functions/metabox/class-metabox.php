<?php

/**
 * Custom MetaBox
 *
 * @package Ovs
 * @author Clément Vacheron
 * @link https://www.overscan.com
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

if (!class_exists('Custom_MetaBox')) {
    class Custom_MetaBox
    {
        //Variable

        /**
         * postType =  nom du post type au quel rattacher les metabox
         * name = Nom de la métabox
         * id = Nom de la metabox en minuscule et avec les espace remplacer par '_'
         */
        protected $postType;
        protected $name;
        protected $id;

        public function setPostType($value)
        {
            $this->postType = $value;
            return $this->postType;
        }
        public function getPostType()
        {
            return $this->postType;
        }
        public function setName($value)
        {
            $this->name = $value;
            return $this->name;
        }
        public function getName()
        {
            return $this->name;
        }
        protected function setId($value)
        {
            $this->id = strtolower(str_replace(' ', '_', $value));
            return $this->id;
        }
        public function getId()
        {
            return $this->id;
        }
        /**
         * Constructor.
         */
        public function __construct($postType, $name)
        {

            $this->setPostType($postType);
            $this->setName($name);
            $this->setId($this->getName());

            if (is_admin()) {
                add_action('load-post.php', array($this, 'init_metabox'));
                add_action('load-post-new.php', array($this, 'init_metabox'));
            }
        }

        /**
         * Meta box initialization.
         */
        public function init_metabox()
        {
            add_action('add_meta_boxes', array($this, 'add_metabox'));
            add_action('save_post', array($this, 'save_metabox'), 10, 2);
        }

        /**
         * Adds the meta box.
         */
        public function add_metabox()
        {
            add_meta_box(
                ($this->getId() . '_meta_box'),
                __('Options' . $this->getName(), 'ovs'),
                array($this, 'render_metabox'),
                $this->getPostType(),
                'normal',
                'high'
            );
        }

        /**
         * Renders the meta box.
         */
        public function render_metabox($post)
        {
            // Add nonce for security and authentication.
            wp_nonce_field($this->getId() . '_metabox', $this->getId() . '_metabox_nonce');
            $image_id = get_post_meta($post->ID, 'cv_custom_image', true);
            $field = '<div>';
            $field .= '<p><b>' . $this->getName() . '</b></p>';
            $field .= '</div>';
            $field .= '<div>';
            $field .= '<h2>Test' . $this->getName() . '</h2>';

            $field .= '</div>';

            echo $field;
        }

        /**
         * Handles saving the meta box.
         *
         * @param int     $post_id Post ID.
         * @param WP_Post $post    Post object.
         * @return null
         */
        public function save_metabox($post_id, $post)
        {
            // Add nonce for security and authentication.
            $nonce_name   = isset($_POST[$this->getId() . '_metabox_nonce']) ? $_POST[$this->getId() . '_metabox_nonce'] : '';
            $nonce_action = $this->getId() . '_metabox';

            // Check if nonce is valid.
            if (!wp_verify_nonce($nonce_name, $nonce_action)) {
                return;
            }

            // Check if user has permissions to save data.
            if (!current_user_can('edit_post', $post_id)) {
                return $post_id;
            }

            // Check if not an autosave.
            if (wp_is_post_autosave($post_id)) {
                return $post_id;
            }

            // Check if not a revision.
            if (wp_is_post_revision($post_id)) {
                return;
            }
            // if (isset($_POST['cv_custom_image']) && array_key_exists('cv_custom_image', $_POST)) {
            //     update_post_meta(
            //         $post_id,
            //         'cv_custom_image',
            //         $_POST['cv_custom_image']
            //     );
            // }
        }
    }
}
