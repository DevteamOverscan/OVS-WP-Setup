<?php

/**
 * Custom MetaBox Image Taxonomie
 * Ajoute la possibilité de mettre une image a une taxonomie
 *
 * @package Ousortir
 * @author Clément Vacheron
 * @link https://www.overscan.com
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

if (!class_exists('Meta_Taxonomy')) {
    class Meta_Taxonomy
    {
        //Variables
        protected $taxonomy; // Id de la taxonomy liée
        protected $fields; // Champs à ajouter

        /**
         * Constructor.
         * @param string $meta
         */
        public function __construct($meta)
        {
            if (is_admin()) {
                add_action($meta . '_add_form_fields', array($this, 'add_term_color_fields'));
                add_action($meta . '_edit_form_fields', array($this, 'edit_term_color_fields'));
                add_action('created_' . $meta, array($this, 'save_term_color_fields'), 10, 2);
                add_action('edited_' . $meta, array($this, 'save_term_color_fields'), 10, 2);

                add_filter('manage_edit-' . $meta . '_columns', array($this, 'add_columns'));
                add_action('manage_' . $meta . '_custom_column', array($this, 'custom_column_color'), 10, 3);
            }
        }
        /**
         * Render input upload add taxonomy
         */
        public function add_term_color_fields($term)
        {
            // Add nonce for security and authentication.
            // wp_nonce_field('taxo_color', 'taxo_color_nonce');
            echo '<div class="form-field term-color-wrap">';
            echo '<div scope="row" valign="top">';
            echo '<label for="term-color">' . _e('Color') . '</label>';
            echo '</div>';
            echo '<div>';
            echo '<input type="text" name="_category_color" class="color-picker" id="term-color" />';
            echo '<input type="hidden" name="_category_color" id="_category_color" readonly />';
            echo '</div>';
            echo '</div>';
        }

        /**
         * Renders input upload edit taxonomy.
         */
        public function edit_term_color_fields($term)
        {
            $value = get_term_meta($term->term_id, '_category_color', true);
            // Add nonce for security and authentication.
            // wp_nonce_field('taxo_color', 'taxo_color_nonce');
            echo '<tr class="form-field">';
            echo '<th scope="row" valign="top">';
            echo '<label for="term-color">' . _e('Color') . '</label>';
            echo '</th>';
            echo '<td>';
            echo '<input type="text" name="_term_color" id="term-color" class="color-picker" value="' . $value . '" />';
            echo '<input type="hidden" name="_category_color" id="_category_color" value="' . $value . '" readonly />';
            echo '</td>';
            echo '</tr>';
        }

        /**
         * Handles saving the meta box.
         *
         * @param int     $post_id Post ID.
         * @param WP_Post $post    Post object.
         * @return null
         */
        public function save_term_color_fields($term_id)
        {
            // Check if user has permissions to save data.
            // if (!current_user_can('edit_post', $term_id)) {
            //     return $term_id;
            // }
            if (isset($_POST['_category_color']) && array_key_exists('_category_color', $_POST)) {
                update_term_meta(
                    $term_id,
                    '_category_color',
                    $_POST['_category_color']
                );
            }
        }

        public function add_columns($columns)
        {
            $test = array('cb' => '<input type="checkbox" />', 'color' => 'Color');
            $columns = array_merge($test, $columns);
            return $columns;
        }
        public function custom_column_color($value, $columns, $term_id)
        {
            switch ($columns) {
                case 'color':
                    // your code here
                    echo '<div class="term-color" style="background-color:' . get_term_meta($term_id, '_category_color', true) . ';"></div>';
                    break;

                default:
                    break;
            }

            // return $value; // this is the display value
        }
    }
}
