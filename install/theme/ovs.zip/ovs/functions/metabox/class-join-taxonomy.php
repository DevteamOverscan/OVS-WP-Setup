<?php

/**
 * Custom MetaBox Image Taxonomie
 * Ajoute la possibilité de mettre une image a une taxonomie
 *
 * @package Ousortir
 * @author Clément Vacheron
 * @link https://www.overscan.com
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

if (!class_exists('CV_Join_Taxonomy')) {
    class CV_Join_Taxonomy
    {
        //Variable

        /**
         * nom de la taxonomy cibler
         */
        protected $taxonomy;
        protected $termJoin;

        public function setTaxonomy($value)
        {
            $this->taxonomy = $value;
            return $this->taxonomy;
        }
        public function getTaxonomy()
        {
            return $this->taxonomy;
        }
        public function setTermJoin($value)
        {
            $this->termJoin = $value;
            return $this->termJoin;
        }
        public function getTermJoin()
        {
            return $this->termJoin;
        }

        /**
         * Constructor.
         * @param string $meta
         */
        public function __construct($meta, $join)
        {
            if (is_admin()) {
                $this->taxonomy = $this->setTaxonomy($meta);
                $this->termJoin = $this->setTermJoin($join);
                add_action($this->getTaxonomy() . '_add_form_fields', array($this, 'add_term_fields'));
                add_action($this->getTaxonomy() . '_edit_form_fields', array($this, 'edit_term_fields'));
                add_action('created_' . $this->getTaxonomy(), array($this, 'save_term_fields'), 10, 2);
                add_action('edited_' . $this->getTaxonomy(), array($this, 'save_term_fields'), 10, 2);

                add_filter('manage_edit-' . $this->getTaxonomy() . '_columns', array($this, 'add_columns'));
                add_action('manage_' . $this->getTaxonomy() . '_custom_column', array($this, 'custom_column'), 10, 3);
            }
        }
        /**
         * Parametres personnalisé pour la taxonomy type
         * Permet de lié une catégorie aux types pour faciliter le filtrage
         */

        /**
         * Render input upload add taxonomy
         */
        public function add_term_fields($term)
        {
            echo '<div class="form-field term-join-taxo-wrap">';
            echo '<div scope="row" valign="top">';
            echo '<label for="_term_join">' . _e('Lier une catégorie lykj') . '</label>';
            echo '</div>';
            echo '<div>';
            echo '<select name="_term_join" id="_term_join">';
            echo '<option value="">' . __('Aucune') . '</option>';
            $cats = get_terms($this->getTermJoin(), 'hide_empty=0');
            if (!empty($cats)) {
                foreach ($cats as $cat) {
                    echo '<option value="' . $cat->term_id . '">' . $cat->name . '</option>';
                }
            }
            echo '</select>';
            echo '</div>';
            echo '</div>';
        }

        /**
         * Renders input upload edit taxonomy.
         */
        public function edit_term_fields($term)
        {
            echo '<tr class="form-field">';
            echo '<th scope="row" valign="top">';
            echo '<label for="_term_join">' . _e('Lier une catégorie') . '</label>';
            echo '</th>';
            echo '<td>';
            echo '<select name="_term_join" id="_term_join">';
            echo '<option value="">' . __('Aucune') . '</option>';
            $cats = get_terms($this->getTermJoin(), 'hide_empty=0');
            $value = get_term_meta($term->term_id, '_term_join', true);
            if (!empty($cats)) {
                foreach ($cats as $cat) {
                    if ($value == $cat->term_id) {
                        echo '<option value="' . $cat->term_id . '" selected>' . $cat->name . '</option>';
                    } else {
                        echo '<option value="' . $cat->term_id . '">' . $cat->name . '</option>';
                    }
                }
            }
            echo '</select>';
            echo '</td>';
            echo '</tr>';
        }

        /**
         * Handles saving the meta box.
         *
         * @param int     $post_id Post ID.
         * @param WP_Post $post    Post object.
         * @return null
         */
        public function save_term_fields($term_id)
        {
            // Check if user has permissions to save data.
            if (!current_user_can('manage_options')) {
                return $term_id;
            }
            if (isset($_POST['_term_join']) && array_key_exists('_term_join', $_POST)) {
                update_term_meta(
                    $term_id,
                    '_term_join',
                    $_POST['_term_join']
                );
            }
        }

        public function add_columns($columns)
        {
            $test = array('cb' => '<input type="checkbox" />', 'name' => 'Nom', 'description' => 'Description', 'join' => 'Term Joint');
            $columns = array_merge($test, $columns);
            return $columns;
        }
        public function custom_column($value, $columns, $term_id)
        {
            switch ($columns) {
                case 'join':
                    // your code here
                    echo get_term(get_term_meta($term_id, '_term_join', true), $this->getTermJoin())->name;
                    break;

                default:
                    break;
            }

            return $value; // this is the display value
        }
    }
}
