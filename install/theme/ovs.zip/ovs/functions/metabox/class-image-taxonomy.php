<?php

/**
 * Custom MetaBox Image Taxonomie
 * Ajoute la possibilité de mettre une image a une taxonomie
 *
 * @package Ousortir
 * @author Clément Vacheron
 * @link https://www.overscan.com
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

if (!class_exists('CV_Image_Taxonomy')) {
    class CV_Image_Taxonomy
    {
        //Variable

        /**
         * nom de la taxonomy cibler
         */
        protected $taxonomy;

        public function setTaxonomy($value)
        {
            $this->taxonomy = $value;
            return $this->taxonomy;
        }
        public function getTaxonomy()
        {
            return $this->taxonomy;
        }
        /**
         * Constructor.
         * @param string $meta
         */
        public function __construct($meta)
        {
            if (is_admin()) {
                add_action($meta . '_add_form_fields', array($this, 'add_term_img_fields'));
                add_action($meta . '_edit_form_fields', array($this, 'edit_term_img_fields'));
                add_action('created_' . $meta, array($this, 'save_term_img_fields'), 10, 2);
                add_action('edited_' . $meta, array($this, 'save_term_img_fields'), 10, 2);

                add_filter('manage_edit-' . $meta . '_columns', array($this, 'add_columns'));
                add_action('manage_' . $meta . '_custom_column', array($this, 'custom_column_img'), 10, 3);
            }
        }
        /**
         * Render input upload add taxonomy
         */
        public function add_term_img_fields($term)
        {
            // Add nonce for security and authentication.
            wp_nonce_field('taxo_image', 'taxo_image_nonce');
            echo '<a href="#" class="cv-upl-img button button-secondary">Upload image</a>
	      <a href="#" class="cv-rmv-img" style="display:none">Remove image</a>
	      <input type="hidden" name="cv-taxo_image" class="cv_save_img" value="">';
        }

        /**
         * Renders input upload edit taxonomy.
         */
        public function edit_term_img_fields($term)
        {
            // Add nonce for security and authentication.
            wp_nonce_field('taxo_image', 'taxo_image_nonce');
            $image_id = get_term_meta($term->term_id, 'cv_taxo_image', true);
            if ($image = wp_get_attachment_url($image_id)) {

                echo '<a href="#" class="cv-upl-img button button-secondary"><img src="' . $image . '" /></a>
	      <a href="#" class="cv-rmv-img">Remove image</a>
	      <input type="hidden" name="cv_taxo_image" class="cv_save_img" value="' . $image_id . '">';
            } else {
                echo '<a href="#" class="cv-upl-img button button-secondary">Upload image</a>
	      <a href="#" class="cv-rmv-img" style="display:none">Remove image</a>
	      <input type="hidden" name="cv_taxo_image" class="cv_save_img" value="">';
            }
        }

        /**
         * Handles saving the meta box.
         *
         * @param int     $post_id Post ID.
         * @param WP_Post $post    Post object.
         * @return null
         */
        public function save_term_img_fields($term_id)
        {
            // Add nonce for security and authentication.
            $nonce_name   = isset($_POST['taxo_image_nonce']) ? $_POST['taxo_image_nonce'] : '';
            $nonce_action = 'taxo_image';

            // Check if nonce is valid.
            // if (!wp_verify_nonce($nonce_name, $nonce_action)) {
            //     return;
            // }

            // Check if user has permissions to save data.
            // if (!current_user_can('edit_post', $term_id)) {
            //     return $term_id;
            // }
            if (isset($_POST['cv_taxo_image']) && array_key_exists('cv_taxo_image', $_POST)) {
                update_term_meta(
                    $term_id,
                    'cv_taxo_image',
                    $_POST['cv_taxo_image']
                );
            }
        }
        public function add_columns($columns)
        {
            $test = array('cb' => '<input type="checkbox" />', 'img' => 'Image');
            $columns = array_merge($test, $columns);
            return $columns;
        }
        public function custom_column_img($value, $columns, $term_id)
        {
            $image_id = get_term_meta($term_id, 'cv_taxo_image', true);
            $imgTaxo = wp_get_attachment_url($image_id);
            switch ($columns) {
                case 'img':
                    // your code here
                    echo '<div class="term-img" style="background-image:url(' . $imgTaxo . ')"></div>';
                    break;

                default:
                    break;
            }

            // return $value; // this is the display value
        }
    }
}
