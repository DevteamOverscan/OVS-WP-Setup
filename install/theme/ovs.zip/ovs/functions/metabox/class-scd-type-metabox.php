<?php

/**
 * Custom MetaBox SecondType
 *
 * @package Ousortir
 * @author Clément Vacheron
 * @link https://www.overscan.com
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

if (!class_exists('CV_SecondType_MetaBox')) {
    class CV_SecondType_MetaBox
    {
        //Variable

        /**
         * nom du post type cibler
         */
        protected $postType;

        public function setPostType($value)
        {
            $this->postType = $value;
            return $this->postType;
        }
        public function getPostType()
        {
            return $this->postType;
        }
        /**
         * Constructor.
         */
        public function __construct()
        {
            if (is_admin()) {
                add_action('load-post.php', array($this, 'init_metabox'));
                add_action('load-post-new.php', array($this, 'init_metabox'));
            }
        }

        /**
         * Meta box initialization.
         */
        public function init_metabox()
        {
            add_action('add_meta_boxes', array($this, 'add_metabox'));
            add_action('save_post',      array($this, 'save_metabox'), 10, 2);
        }

        /**
         * Adds the meta box.
         */
        public function add_metabox()
        {
            add_meta_box(
                'type-meta-box',
                __('Second Type', 'ousortir'),
                array($this, 'render_metabox'),
                $this->getPostType(),
                'side',
            );
        }

        /**
         * Renders the meta box.
         */
        public function render_metabox($post)
        {
            // Add nonce for security and authentication.
            // wp_nonce_field('scdtype_metabox', 'scdtype_metabox_nonce');
            $secondType = get_post_meta($post->ID, 'cv_second_type', true);
            $secondTypeCat = get_post_meta($post->ID, 'cv_scdType_cat', true);
            $types = array('resto' => 'Restaurant', 'party' => 'Soirée', 'culture' => 'Culturel', 'balade' => 'Balade', 'activities' => 'Activités', 'shop' => 'Shop');
            $field = '<div>';
            $field .= '<p><b>Second Type</b></p>';
            $field .= '</div>';
            $field .= '<div>';
            $field .= '<p>Choisir une autre fonction de l\'établissement. Celui-ci sera également affiché sur la page correspondant à la fonction choisie.</p>';
            $field .= '<div>';
            $field .= '<select name="cv_second_type" id="cv_second_type">';
            $field .= '<option value="">--</option>';
            foreach ($types as $key => $value) {
                if (!empty($secondType) && $secondType === $key) {
                    $field .= '<option value="' . $key . '" selected>' . $value . '</option>';
                } else {
                    $field .= '<option value="' . $key . '">' . $value . '</option>';
                }
            }
            $field .= '</select>';
            $field .= '</div>';
            foreach ($types as $key => $value) {
                if (!empty($secondType) && $secondType === $key) {
                    $field .= '<div class="scdType-cat scdType-' . $key . ' show">';
                } else {
                    $field .= '<div class="scdType-cat scdType-' . $key . '">';
                }
                $field .= '<p><b>' . $value . ' catégorie</b></p>';
                $field .= '<p>Ajouter une catégorie du second type d\'établissement. Cela permet à l\'établissement d\'être associé aux filtres de la page du second type.</p>';
                $catType = $this->getTaxonomy($key);
                foreach ($catType as $id => $cat) {
                    $field .= '<div><label for="' . $id . '_' . $cat . '">';
                    if (!empty($secondTypeCat) && in_array($id, $secondTypeCat)) {
                        $field .= '<input type="checkbox" name="cv_scdType_cat[]" id="' . $id . '_' . $cat . '" value="' . $id . '" checked>';
                    } else {
                        $field .= '<input type="checkbox" name="cv_scdType_cat[]" id="' . $id . '_' . $cat . '" value="' . $id . '">';
                    }
                    $field .= $cat . '</label></div>';
                }


                $field .= '</div>';
            }
            $field .= '</div>';

            echo $field;
        }

        /**
         * Handles saving the meta box.
         *
         * @param int     $post_id Post ID.
         * @param WP_Post $post    Post object.
         * @return null
         */
        public function save_metabox($post_id, $post)
        {

            // Check if user has permissions to save data.
            if (!current_user_can('edit_post', $post_id)) {
                return $post_id;
            }

            // Check if not an autosave.
            if (wp_is_post_autosave($post_id)) {
                return $post_id;
            }

            // Check if not a revision.
            if (wp_is_post_revision($post_id)) {
                return;
            }
            if (isset($_POST['cv_second_type']) && array_key_exists('cv_second_type', $_POST)) {
                update_post_meta(
                    $post_id,
                    'cv_second_type',
                    $_POST['cv_second_type']
                );
            }
            if (isset($_POST['cv_scdType_cat']) && array_key_exists('cv_scdType_cat', $_POST)) {
                update_post_meta(
                    $post_id,
                    'cv_scdType_cat',
                    $_POST['cv_scdType_cat']
                );
            }
        }

        protected function getTaxonomy($cat)
        {
            $taxo = array();
            if ($cat !== 'post') {
                $terms = get_categories(array('taxonomy' => $cat . '_category'));
            } else {
                $terms = get_categories();
            }
            if (!empty($terms) && !is_wp_error($terms)) {
                foreach ($terms as $term) {
                    $taxo[$term->term_id] = $term->name;
                }
            }
            return $taxo;
        }
    }
}
