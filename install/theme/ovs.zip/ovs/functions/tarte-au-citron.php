<?php

add_action('wp_footer', 'tarteaucitron_services');

function tarteaucitron_services()
{ ?>
    <script>
        // ----------Google analytics GA4
        tarteaucitron.user.gtagUa = 'G-XXXXXXXXX';
        // tarteaucitron.user.gtagCrossdomain = ['example.com', 'example2.com'];
        tarteaucitron.user.gtagMore = function() {
            /* add here your optionnal gtag() */ };
        (tarteaucitron.job = tarteaucitron.job || []).push('gtag');
        // ---------Google analytics GA
        tarteaucitron.user.gajsUa = 'UA-XXXXXXXX-X';
        tarteaucitron.user.gajsMore = function() {
            /* add here your optionnal _ga.push() */ };
        (tarteaucitron.job = tarteaucitron.job || []).push('gajs');
        // ---------Google analytics multiple
        tarteaucitron.user.multiplegtagUa = ['UA-XXXXXXXX-X', 'UA-XXXXXXXX-X', 'UA-XXXXXXXX-X'];
        (tarteaucitron.job = tarteaucitron.job || []).push('multiplegtag');
        // ---------Google analytics (old)
        tarteaucitron.user.analyticsUa = 'UA-XXXXXXXX-X';
        tarteaucitron.user.analyticsMore = function() {
            /* optionnal ga.push() */ };
        tarteaucitron.user.analyticsUaCreate = {
            /* optionnal create configuration */ };
        tarteaucitron.user.analyticsAnonymizeIp = true;
        tarteaucitron.user.analyticsPageView = {
            /* optionnal pageview configuration */ };
        tarteaucitron.user.analyticsMore = function() {
            /* optionnal ga.push() */ };
        (tarteaucitron.job = tarteaucitron.job || []).push('analytics');
        // ---------Google ads
        tarteaucitron.user.googleadsId = 'AW-XXXXXXXXX';
        (tarteaucitron.job = tarteaucitron.job || []).push('googleads');
        // ---------Google Maps
        tarteaucitron.user.googlemapsKey = 'API KEY';
        (tarteaucitron.job = tarteaucitron.job || []).push('googlemaps');
        // ---------Google Maps noapi
        (tarteaucitron.job = tarteaucitron.job || []).push('maps_noapi');
        // ---------Google Agenda
        (tarteaucitron.job = tarteaucitron.job || []).push('gagenda');
        // ---------Google Docs
        (tarteaucitron.job = tarteaucitron.job || []).push('gdocs');
        // ---------Google Sheets
        (tarteaucitron.job = tarteaucitron.job || []).push('gsheets');
        // ---------openstreetmap embed iframe
        (tarteaucitron.job = tarteaucitron.job || []).push('openstreetmap');
        // ---------recaptcha
        tarteaucitron.user.recaptchaapi = 'XXXXX';
        (tarteaucitron.job = tarteaucitron.job || []).push('recaptcha');
        // ---------soundcloud
        (tarteaucitron.job = tarteaucitron.job || []).push('soundcloud');
        // ---------spotify
        (tarteaucitron.job = tarteaucitron.job || []).push('spotify');
        // ---------youtube
        (tarteaucitron.job = tarteaucitron.job || []).push('youtube');
        // ---------youtubeapi
        (tarteaucitron.job = tarteaucitron.job || []).push('youtubeapi');
        // ---------facebook pixel
        tarteaucitron.user.facebookpixelId = 'YOUR-ID';
        tarteaucitron.user.facebookpixelMore = function() {
            /* add here your optionnal facebook pixel function */ };
        (tarteaucitron.job = tarteaucitron.job || []).push('facebookpixel');
    </script>
<?php };
?>