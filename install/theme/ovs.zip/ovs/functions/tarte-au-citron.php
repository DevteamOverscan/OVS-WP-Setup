<?php

// add_action('wp_footer', 'tarteaucitron_services');

function tarteaucitron_services()
{ ?>
<script>
    tarteaucitron.user.analyticsUa = 'UA-XXXXXXXX-X';
    tarteaucitron.user.analyticsMore = function() {
        ga('set', 'anonymizeIp', true);
    };
    (tarteaucitron.job = tarteaucitron.job || []).push('analytics');
</script>
<?php };
?>