# Configuration Thème enfant

## function.php

**Inclusion de fichiers de functions personnalisées**

Activés uniquement les fichiers dont vous avez besoin

1. Obligatoires :

- '/functions/security-wp.php',
- '/functions/security-admin.php',
- '/functions/security-force-brut.php',

Plus d'informations sur le [WIKI](https://overscan.getoutline.com/doc/optimiser-linstallation-pour-plus-de-securite-CLDLet8oyr)

2. Obligatoires si Elementor :

- '/ovs-elementor/class_Widgets.php',
- '/ovs-elementor/class_Controls.php',
- '/ovs-elementor/controls/Controls_Manager.php',
- '/ovs-elementor/widgets/traits/button-trait.php',

3. Recommandés :

- '/functions/remove-comments.php',
- '/functions/tarte-au-citron.php', (active la gestion des cookies, vérifier la version sinon télécharger la dernière [ici](https://tarteaucitron.io/fr/install/) )

4. Optionnels :

- '/functions/share-button.php', (ajoute les liens de partages sur les réseaux sociaux pour les articles)
- '/functions/duplicate-post-page.php', (ajoute une fonction qui permet de dupliqué les différent type de contenu).

**Nettoie la table dans la base de donné de woocommerce**
Supprimer les fonctions si ce n'est pas un e-commerce.

## ovs-elementor => class_Widget

Dans l'array $widgets, ajouter les widgets utilisé sur le site. Supprimer les autres.

Le code suivant permet d'activer la traduction des widgets personnaliser avec WPML
`if(method_exists($w, 'add_wpml_support')) {
    $w->add_wpml_support();
}`

## Widgets

### Traductions

Si pas présent dans le fichier de base de configuration de votre Widget (EWidget_Nom_Du_Widget).

Ajouter la fonction suivante pour activer la traduction avec WPML (normalement à la fin du fichier).

`public function add_wpml_support()
{
    add_filter('wpml_elementor_widgets_to_translate', [$this, 'wpml_widgets_to_translate_filter']);
}`

Configurer les éléments traductible de votre widget.
``public function wpml_widgets_to_translate_filter($widgets)
{
$widgets[ $this->get_name() ] = [
'conditions' => [ 'widgetType' => $this->get_name() ],
'fields' => [
[
'field' => 'title_text',
'type' => __('Img Box : Title', 'ovs'),
'editor_type' => 'LINE'
],
[
'field' => 'description_text',
'type' => __('Img Box : Description', 'ovs'),
'editor_type' => 'LINE'
],
],
];

    return $widgets;

}``

**field** = identifiant du champs que vous avez dans le add_control.
**type** = indication qui sera affiché dans l'éditeur de WPML
**editor_type** = Type de champs as utilisé dans l'éditeur WPML (AREA, LINE, VISUAL)

Plus d'information sur la [docs WPML](https://wpml.org/documentation/plugins-compatibility/elementor/how-to-add-wpml-support-to-custom-elementor-widgets/)
