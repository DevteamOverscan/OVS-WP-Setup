<?php

/**
 **  activation theme
 **/

// --------------------------------------- //
// --       Ajout du css custom          -- //
// --------------------------------------- //
function theme_enqueue_styles() {
    // Récupérer la liste des styles enregistrés
    $registered_styles = wp_styles()->registered;
    
    // Parcourir les styles enregistrés pour trouver le parent-style
    foreach ($registered_styles as $style) {
        // Vérifier si le style a un parent (dépendance)
        if (!empty($style->deps)) {
            // Vérifier si le parent-style est un thème parent
            if ($style->handle !== 'child-style' && !is_child_theme()) {
                // Utiliser le parent-style trouvé comme dépendance pour le child-style
                wp_enqueue_style('child-style', get_stylesheet_directory_uri() . '/style.css', array($style->handle));
                break; // Sortir de la boucle dès que le parent-style est trouvé
            }
        }
    }
}
add_action('wp_enqueue_scripts', 'theme_enqueue_styles',15);

// /**
//  * Custom CSS Editor Elementor
//  */
// function elementor_css()
// {
//     wp_enqueue_style('editor', get_stylesheet_directory_uri() . '/ovs-elementor/assets/css/editor-ovs.css', null, CHILD_THEME_ASTRA_CHILD_VERSION);
//     wp_enqueue_style('icon-font', get_stylesheet_directory_uri() . '/assets/css/style-icon.css', null, CHILD_THEME_ASTRA_CHILD_VERSION);
// }
// add_action('elementor/editor/after_enqueue_styles', 'elementor_css');


// --------------------------------------- //
// --       Ajout du js custom          -- //
// --------------------------------------- //
add_action('wp_enqueue_scripts', 'custom_script', 95);
function custom_script()
{
    wp_register_script('app', get_stylesheet_directory_uri() . '/assets/front/js/app.js', array('jquery'), false, true);
    wp_enqueue_script('app');
}

// ----------------------------------------- //
// --  Ajout css et js custom pour admin  -- //
// ----------------------------------------- //
function admin_include_script()
{

    if (!did_action('wp_enqueue_media')) {
        wp_enqueue_media();
    }
    wp_enqueue_script('admin-script', get_stylesheet_directory_uri() . '/assets/admin/admin.js', array('jquery'), false, true);
    wp_enqueue_style('admin-css', get_stylesheet_directory_uri() . '/assets/admin/admin.css', false, '1.0.0');
}
add_action('admin_enqueue_scripts', 'admin_include_script', 11);
